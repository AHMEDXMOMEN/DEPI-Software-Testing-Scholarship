package openCart_project.openCart_project_final;

import org.testng.annotations.Test;

public class AddToCartNegativeTests extends TestBase {

    ProductPage productObject;
    CartPage cartObject;

    @Test(priority = 1)
    public void addToCartAsGuest_NegativeFlow() throws InterruptedException{
        productObject = new ProductPage(driver);
        Thread.sleep(2000);
        cartObject = new CartPage(driver);
        Thread.sleep(2000);

        driver.navigate().to("https://awesomeqa.com/ui/index.php?route=product/product&product_id=43");
        Thread.sleep(2000);

        productObject.testSetQuantity();
        Thread.sleep(2000);

        productObject.testClickAddToCart();
        Thread.sleep(2000);

        cartObject.testOpenCartDropdown();
        Thread.sleep(2000);

        cartObject.testClickCheckout();
        Thread.sleep(2000);

        cartObject.testGuestCheckoutVisible();
        Thread.sleep(2000);

    }
}
