package openCart_project.openCart_project_final;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterTests_PositiveScenario extends TestBase {

    HomePage homeObject;
    ReigsterPage registerObject;
    AccountCreatedPage accountCreatedObject;

    @Test(priority = 1)
    public void registerTest_NewEmail_Mandatory() throws InterruptedException {
        homeObject = new HomePage(driver);
        registerObject = new ReigsterPage(driver);
        accountCreatedObject = new AccountCreatedPage(driver);

        homeObject.openRegisterPage();

        // Perform registration with one set of data
        registerObject.enterYourPersonalDetails("Maryam", "Ayman", "one_time_test002@gmail.com", "01016489067", "123456");
        registerObject.selectNewsletterSubscription(); 
        registerObject.agreeToTerms();
        registerObject.clickContinue();

        Assert.assertTrue(accountCreatedObject.isAccountCreatedMessageDisplayed(), "Account creation failed.");
        Thread.sleep(3000);
        accountCreatedObject.clickContinue();  
    }
}
