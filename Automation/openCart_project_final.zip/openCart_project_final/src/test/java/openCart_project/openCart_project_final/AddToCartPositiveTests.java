package openCart_project.openCart_project_final;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class AddToCartPositiveTests extends TestBase {

    HomePage homeObject;
    LoginPage loginObject;
    ProductPage productObject;
    CartPage cartObject;

    @Test(priority = 1)
    public void loginAndAddToCart_PositiveFlow() throws InterruptedException {
        homeObject = new HomePage(driver);
        loginObject = new LoginPage(driver);
        productObject = new ProductPage(driver);
        cartObject = new CartPage(driver);

        // Step 1: Open login page
        homeObject.openLoginPage();
        Thread.sleep(2000);

        // Step 2: Perform login
        loginObject.userCanLogin("maryamaymann223@gmail.com", "123456");
        Thread.sleep(2000);

        // Step 3: Verify login
        assert loginObject.logoutBtn.isDisplayed();
        Thread.sleep(2000);

        // Step 4: Click on logo to return to homepage
        WebElement logo = driver.findElement(By.cssSelector("img[title='TheTestingAcademy eCommerce']"));
        logo.click();
        Thread.sleep(2000);

        // Step 5: Click on MacBook product
        WebElement macbookLink = driver.findElement(By.linkText("MacBook"));
        macbookLink.click();
        Thread.sleep(2000);

        // Step 6: Set quantity
        productObject.testSetQuantity();
        Thread.sleep(2000);

        // Step 7: Add to cart
        productObject.testClickAddToCart();
        Thread.sleep(2000);

        // Step 8: Open cart dropdown
        cartObject.testOpenCartDropdown();
        Thread.sleep(2000);

        // Step 9: Click checkout
        cartObject.testClickCheckout();
        Thread.sleep(2000);
    }
}
