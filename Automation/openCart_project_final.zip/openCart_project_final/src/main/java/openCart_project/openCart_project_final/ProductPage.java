package openCart_project.openCart_project_final;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

public class ProductPage extends PageBase {

    public ProductPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "input-quantity")
    WebElement quantityTxt;

    @FindBy(id = "button-cart")
    WebElement addToCartBtn;

    // ========== TEST CASES ==========

    @Test(priority = 1)
    public void testSetQuantity() {
        quantityTxt.clear();
        quantityTxt.sendKeys("1");
    }

    @Test(priority = 2)
    public void testClickAddToCart() {
        addToCartBtn.click();
    }
}
