package openCart_project.openCart_project_final;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ReigsterPage extends PageBase {

    public ReigsterPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "input-firstname")
    WebElement firstnameTxt;

    @FindBy(id = "input-lastname")
    WebElement lastnameTxt;

    @FindBy(id = "input-email")
    WebElement emailTxt;

    @FindBy(id = "input-telephone")
    WebElement telephoneTxt;

    @FindBy(id = "input-password")
    WebElement passwordTxt;

    @FindBy(id = "input-confirm")
    WebElement confirmTxt;

    @FindBy(xpath = "//*[@id='content']/form/fieldset[3]/div/div/label[1]/input")
    WebElement subscribeYesBtn;

    @FindBy(xpath = "//*[@id='content']/form/fieldset[3]/div/div/label[2]/input")
    WebElement subscribeNoBtn;

    @FindBy(name = "agree")
    WebElement agreeCheckbox;

    @FindBy(xpath = "//*[@id='content']/form/div/div/input[2]")
    WebElement continueBtn;

    @FindBy(css = "#account-register > div.alert.alert-danger.alert-dismissible")
    public WebElement accountAlreadyExistMsg;

    // ==== Actions ====

    public void enterYourPersonalDetails(String firstName, String lastName, String email, String telephone, String password) {
        firstnameTxt.sendKeys(firstName);
        lastnameTxt.sendKeys(lastName);
        emailTxt.sendKeys(email);
        telephoneTxt.sendKeys(telephone);
        passwordTxt.sendKeys(password);
        confirmTxt.sendKeys(password);
    }

    public void selectNewsletterSubscription() {
        subscribeYesBtn.click();
    }

    public void agreeToTerms() {
        if (!agreeCheckbox.isSelected()) {
            agreeCheckbox.click();
        }
    }

    public void clickContinue() {
        continueBtn.click();
    }
}
