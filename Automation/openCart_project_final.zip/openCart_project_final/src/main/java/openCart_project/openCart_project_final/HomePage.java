package openCart_project.openCart_project_final;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends PageBase{

	HomePage(WebDriver driver) {
		super(driver);
		
	}

	
	 @FindBy(linkText = "My Account")
	    WebElement myAccountBtn;

	    @FindBy(linkText = "Register")
	    WebElement registerBtn;
	    
	    @FindBy(linkText = "Login")
		WebElement loginLink;
		

	    public void openRegisterPage() {
	        myAccountBtn.click();
	        registerBtn.click();
	    }
	    
	    public void clickMyAccount() {
			myAccountBtn.click();  
		}
	    
	    public void openLoginPage() {
			clickMyAccount();      
			loginLink.click();
		}
}
