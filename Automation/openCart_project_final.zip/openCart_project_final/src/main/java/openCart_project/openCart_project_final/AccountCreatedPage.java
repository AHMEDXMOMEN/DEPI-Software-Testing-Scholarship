package openCart_project.openCart_project_final;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountCreatedPage extends PageBase {

    public AccountCreatedPage(WebDriver driver) {
        super(driver);
    }
    
    @FindBy(xpath = "//*[@id=\"content\"]/h1")
    WebElement accountCreationMessage;
    
    @FindBy(xpath = "//*[@id=\"content\"]/div/div/a")
    WebElement continueBtn;
  
    public boolean isAccountCreatedMessageDisplayed() {
        return accountCreationMessage.isDisplayed(); // to verify if account creation message is visible
    }

    public void clickContinue() {
        continueBtn.click(); 
    }
}
