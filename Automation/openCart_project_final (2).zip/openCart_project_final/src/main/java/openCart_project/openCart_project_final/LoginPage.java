package openCart_project.openCart_project_final;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends PageBase {

	public LoginPage(WebDriver driver) {
		super(driver);
		
	}

	@FindBy(id ="input-email")
	WebElement emailTxt;
	
	@FindBy(id ="input-password")
	WebElement passwordTxt;
	
	@FindBy(xpath ="//*[@id=\"content\"]/div/div[2]/div/form/input")
	WebElement loginBtn;
	
	@FindBy(xpath ="//*[@id=\"content\"]/div/div[2]/div/h2")
	public WebElement loginMessage ;
	
	@FindBy(partialLinkText = "Logout")
	public WebElement logoutBtn;

    @FindBy(css = "#account-login > div.alert.alert-danger.alert-dismissible")
    public WebElement failedMessage;

	
	public void userCanLogin(String email , String password) {
	
	emailTxt.sendKeys(email);
	passwordTxt.sendKeys(password);
	loginBtn.click();
	
	}
	
	public void userCanLogout() {
		logoutBtn.click();
	
	}		
}