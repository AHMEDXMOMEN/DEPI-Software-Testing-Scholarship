package openCart_project.openCart_project_final;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

public class CartPage extends PageBase {

    public CartPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = "#cart > button")
    WebElement cartDropdownBtn;

    @FindBy(xpath = "//a[contains(@href, 'checkout/checkout')]")
    WebElement checkoutBtn;

    @FindBy(xpath = "//label[contains(text(), 'I want to use an existing address')]")
    WebElement existingAddressRadio;

    @FindBy(xpath = "//h2[text()='New Customer']")
    WebElement newCustomerHeader;

    // ========== TEST CASES ==========

    @Test(priority = 3)
    public void testOpenCartDropdown() {
        cartDropdownBtn.click();
    }

    @Test(priority = 4)
    public void testClickCheckout() {
        checkoutBtn.click();
    }

    @Test(priority = 5)
    public void testLoggedInCheckoutVisible() {
        assert existingAddressRadio.isDisplayed();
    }

    @Test(priority = 6)
    public void testGuestCheckoutVisible() {
        assert newCustomerHeader.isDisplayed();
    }
}
