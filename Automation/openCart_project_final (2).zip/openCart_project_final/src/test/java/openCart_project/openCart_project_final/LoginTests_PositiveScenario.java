package openCart_project.openCart_project_final;

import org.testng.annotations.Test;
import org.testng.Assert;

public class LoginTests_PositiveScenario extends TestBase {

    HomePage homeObject;
    LoginPage loginObject;

    @Test(priority = 1)
    public void testLogin_CorrectUserNameAndPassword() throws InterruptedException {
        homeObject = new HomePage(driver);
        loginObject = new LoginPage(driver);

        homeObject.openLoginPage();

        Assert.assertEquals(loginObject.loginMessage.getText(), "Returning Customer");

        loginObject.userCanLogin("maryamaymann223@gmail.com", "123456");

        Assert.assertTrue(loginObject.logoutBtn.isDisplayed(), "Logout button is not displayed after login.");

        loginObject.userCanLogout();
    }
}
