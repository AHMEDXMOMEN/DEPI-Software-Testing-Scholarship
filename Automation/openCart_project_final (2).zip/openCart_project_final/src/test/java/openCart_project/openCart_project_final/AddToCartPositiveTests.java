package openCart_project.openCart_project_final;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class AddToCartPositiveTests extends TestBase {

    HomePage homeObject;
    LoginPage loginObject;
    ProductPage productObject;
    CartPage cartObject;

    @Test(priority = 1)
    public void loginAndAddToCart_PositiveFlow() throws InterruptedException {
        homeObject = new HomePage(driver);
        loginObject = new LoginPage(driver);
        productObject = new ProductPage(driver);
        cartObject = new CartPage(driver);

        homeObject.openLoginPage();
        Thread.sleep(2000);

        loginObject.userCanLogin("ahmed@gmail.com", "123456");
        Thread.sleep(2000);

        assert loginObject.logoutBtn.isDisplayed();
        Thread.sleep(2000);

        WebElement logo = driver.findElement(By.cssSelector("img[title='TheTestingAcademy eCommerce']"));
        logo.click();
        Thread.sleep(2000);

        WebElement macbookLink = driver.findElement(By.linkText("MacBook"));
        macbookLink.click();
        Thread.sleep(2000);

        productObject.testSetQuantity();
        Thread.sleep(2000);

        productObject.testClickAddToCart();
        Thread.sleep(2000);

        cartObject.testOpenCartDropdown();
        Thread.sleep(2000);

        cartObject.testClickCheckout();
        Thread.sleep(2000);
    }
}
