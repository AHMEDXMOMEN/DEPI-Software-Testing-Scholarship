package openCart_project.openCart_project_final;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriver;
public class TestBase {
  
	protected WebDriver driver = new EdgeDriver();

	protected String baseURL = "https://awesomeqa.com/ui/index.php?route=common/home";
	
	 @BeforeTest
	    public void openBrowser() {
	    	driver.manage().window().maximize();
	    	driver.navigate().to(baseURL);
	    }

	    @AfterTest
	    public void closeBrowser() {
	    	driver.quit();
	    }

}
